#!/bin/bash
cd "$(dirname "$0")"

clear
echo "================================================================"
echo "    Transact Bridge - Deploy Dashboard to Vercel"
echo "================================================================"
echo ""
echo "Building public assets..."
npm run build 2>/dev/null

echo "Deploying to Vercel..."
echo ""

npx vercel --prod

echo ""
echo "================================================================"
echo "Deployment finished! You can close this window."
echo "================================================================"
read -p "Press Enter to exit..."
